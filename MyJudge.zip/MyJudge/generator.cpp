#include <bits/stdc++.h>
#include "utilities.h"
using namespace std;
// faster


int main() {
    ios::sync_with_stdio(0);

    for (int index = 1; index <= NUM_TESTS; index++) {
        ofstream inp(inputName(index).c_str());
        
        inp << 1 << endl;
        int a =rand(-20000,20000);
        int b =rand(-20000,20000);
        int c =rand(-20000,20000);

        inp << a << ' ' << b << ' ' << c;

    }
    return 0;
}