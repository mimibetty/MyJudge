#include <bits/stdc++.h>
using namespace std;

int main() {
    // freopen("input.txt", "r", stdin);
    ios::sync_with_stdio(0);
    cin.tie(NULL);

    int t;
    cin >> t;
    for (int z = 1; z <= t; z++) {
        int a, b, c;
        cin >> a >> b >> c;

        if (a == 0) {
            if (b == 1 || c == 0) cout << "oo\n";
            else cout << 0 << "\n";
            continue;
        }

        if (c == 0) {
            cout << "oo\n"; 
        }
        else {
            if (c % 2) {
                if ((b - 1) % a == 0) cout << 1 << "\n";
                else cout << 0 << "\n";
            }
            else {
                int cnt = 0;
                if ((b - 1) % a == 0) cnt++;
                if ((b + 1) % a == 0) cnt++;
                cout << cnt << "\n";
            }
        }
    }
    
    return 0;
}